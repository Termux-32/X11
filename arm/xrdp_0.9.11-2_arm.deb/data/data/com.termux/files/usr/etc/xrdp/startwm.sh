#!/data/data/com.termux/files/usr/bin/env bash
#
# This script is an example. You might need to edit this script
# depending on your distro if it doesn't work for you.
#
# Uncomment the following line for debug:
# exec aterm


# Execution sequence for interactive login shell - pseudocode
#
# IF /data/data/com.termux/files/usr/etc/profile is readable THEN
#     execute ~/.bash_profile
# END IF
# IF ~/.bash_profile is readable THEN
#     execute ~/.bash_profile
# ELSE
#     IF ~/.bash_login is readable THEN
#         execute ~/.bash_login
#     ELSE
#         IF ~/.profile is readable THEN
#             execute ~/.profile
#         END IF
#     END IF
# END IF
pre_start()
{
  if [ -r /data/data/com.termux/files/usr/etc/profile ]; then
    . /data/data/com.termux/files/usr/etc/profile
  fi
  if [ -r ~/.bash_profile ]; then
    . ~/.bash_profile
  else
    if [ -r ~/.bash_login ]; then
      . ~/.bash_login
    else
      if [ -r ~/.profile ]; then
        . ~/.profile
      fi
    fi
  fi
  return 0
}

# When loging out from the interactive shell, the execution sequence is:
#
# IF ~/.bash_logout exists THEN
#     execute ~/.bash_logout
# END IF
post_start()
{
  if [ -r ~/.bash_logout ]; then
    . ~/.bash_logout
  fi
  return 0
}

#start the window manager
wm_start()
{
  pre_start
  aterm
  post_start
}

#PATH="/data/data/com.termux/files/usr/bin:/data/data/com.termux/files/usr/bin/applets"
#export PATH=$PATH

wm_start

exit 1
